
//* 定义 svg 的扩展类型
declare module '*.svg' {
  const content: any;
  export default content;
}